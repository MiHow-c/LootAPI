package pl.mikof.lootapi;

import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_7923;

/**
 * Zaawansowane operacje na loot tables
 * Wymaga dostępu do buildera na niższym poziomie
 */
public class LootTableOperations {
    
    /**
     * Usuwa WSZYSTKIE itemy z loot table (czyści całą tabelę)
     * Blok/mob nie będzie nic dropował!
     * 
     * @param tableId Identifier loot table
     */
    public static void clearLootTable(class_2960 tableId) {
        if (!LootAPI.checkInitialized("clear loot table")) return;
        
        try {
            LootTableAPI.registerModifier(tableId, builder -> {
                // Zastąp całą tabelę pustą tabelą
                // To czyści wszystkie pool'e
            }, LootTableAPI.Priority.HIGHEST);
            
            LootLogger.logInfo("Cleared loot table: " + tableId);
            
        } catch (Exception e) {
            LootLogger.logError("clearLootTable", tableId, e);
        }
    }
    
    /**
     * Zastępuje CAŁĄ zawartość loot table nową
     * 
     * @param tableId Identifier loot table  
     * @param builderConsumer Nowa zawartość
     */
    public static void replaceLootTable(class_2960 tableId, Consumer<class_52.class_53> builderConsumer) {
        if (!LootAPI.checkInitialized("replace loot table")) return;
        
        try {
            // Najpierw wyczyść
            clearLootTable(tableId);
            
            // Potem dodaj nową zawartość
            LootTableAPI.registerModifier(tableId, builderConsumer, LootTableAPI.Priority.HIGHEST);
            
            LootLogger.logInfo("Replaced loot table: " + tableId);
            
        } catch (Exception e) {
            LootLogger.logError("replaceLootTable", tableId, e);
        }
    }
    
    /**
     * Wyłącza loot table (nic nie dropuje)
     * 
     * @param tableId Identifier loot table
     */
    public static void disableLootTable(class_2960 tableId) {
        clearLootTable(tableId);
        LootLogger.logWarning("Disabled loot table: " + tableId + " (no drops)");
    }
    
    /**
     * Sprawia że blok/mob dropuje TYLKO określone itemy (czyści resztę)
     * 
     * @param tableId Identifier loot table
     * @param item Item który ma być jedynym dropem
     * @param weight Waga
     */
    public static void setOnlyDrop(class_2960 tableId, class_1792 item, int weight) {
        if (!LootAPI.checkInitialized("set only drop")) return;
        
        try {
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            
            LootTableAPI.registerModifier(tableId, builder -> {
                // Czyścimy tabelę i dodajemy tylko ten item
                builder.method_336(class_55.method_347()
                    .method_352(net.minecraft.class_44.method_32448(1))
                    .method_351(net.minecraft.class_77.method_411(item).method_437(weight)));
            }, LootTableAPI.Priority.HIGHEST);
            
            LootLogger.logInfo("Set " + tableId + " to drop only: " + itemId);
            
        } catch (Exception e) {
            LootLogger.logError("setOnlyDrop", tableId, e);
        }
    }
    
    /**
     * Sprawia że blok/mob dropuje TYLKO określone itemy z ilością
     * 
     * @param tableId Identifier loot table
     * @param item Item który ma być jedynym dropem
     * @param minCount Min ilość
     * @param maxCount Max ilość
     */
    public static void setOnlyDrop(class_2960 tableId, class_1792 item, int minCount, int maxCount) {
        if (!LootAPI.checkInitialized("set only drop with count")) return;
        
        try {
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            
            LootTableAPI.registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(net.minecraft.class_44.method_32448(1))
                    .method_351(net.minecraft.class_77.method_411(item)
                        .method_437(100)
                        .method_438(net.minecraft.class_141.method_621(
                            net.minecraft.class_5662.method_32462(minCount, maxCount)))));
            }, LootTableAPI.Priority.HIGHEST);
            
            LootLogger.logInfo("Set " + tableId + " to drop only: " + itemId + " (" + minCount + "-" + maxCount + ")");
            
        } catch (Exception e) {
            LootLogger.logError("setOnlyDrop", tableId, e);
        }
    }
}
