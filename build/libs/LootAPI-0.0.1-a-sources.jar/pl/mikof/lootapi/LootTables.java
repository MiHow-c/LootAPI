package pl.mikof.lootapi;

import net.minecraft.class_2960;

/**
 * Klasa pomocnicza z predefiniowanymi ścieżkami do loot tables
 * Ułatwia dostęp - zamiast new Identifier("minecraft", "blocks/diamond_ore")
 * można użyć LootTables.Blocks.DIAMOND_ORE
 */
public class LootTables {
    
    // ========== BLOKI - RUDY ==========
    public static class Blocks {
        // Vanilla ores
        public static final class_2960 COAL_ORE = id("blocks/coal_ore");
        public static final class_2960 DEEPSLATE_COAL_ORE = id("blocks/deepslate_coal_ore");
        public static final class_2960 IRON_ORE = id("blocks/iron_ore");
        public static final class_2960 DEEPSLATE_IRON_ORE = id("blocks/deepslate_iron_ore");
        public static final class_2960 GOLD_ORE = id("blocks/gold_ore");
        public static final class_2960 DEEPSLATE_GOLD_ORE = id("blocks/deepslate_gold_ore");
        public static final class_2960 DIAMOND_ORE = id("blocks/diamond_ore");
        public static final class_2960 DEEPSLATE_DIAMOND_ORE = id("blocks/deepslate_diamond_ore");
        public static final class_2960 EMERALD_ORE = id("blocks/emerald_ore");
        public static final class_2960 DEEPSLATE_EMERALD_ORE = id("blocks/deepslate_emerald_ore");
        public static final class_2960 LAPIS_ORE = id("blocks/lapis_ore");
        public static final class_2960 DEEPSLATE_LAPIS_ORE = id("blocks/deepslate_lapis_ore");
        public static final class_2960 REDSTONE_ORE = id("blocks/redstone_ore");
        public static final class_2960 DEEPSLATE_REDSTONE_ORE = id("blocks/deepslate_redstone_ore");
        public static final class_2960 COPPER_ORE = id("blocks/copper_ore");
        public static final class_2960 DEEPSLATE_COPPER_ORE = id("blocks/deepslate_copper_ore");
        
        // Nether ores
        public static final class_2960 NETHER_GOLD_ORE = id("blocks/nether_gold_ore");
        public static final class_2960 NETHER_QUARTZ_ORE = id("blocks/nether_quartz_ore");
        public static final class_2960 ANCIENT_DEBRIS = id("blocks/ancient_debris");
        
        // Stone variants
        public static final class_2960 STONE = id("blocks/stone");
        public static final class_2960 COBBLESTONE = id("blocks/cobblestone");
        public static final class_2960 GRANITE = id("blocks/granite");
        public static final class_2960 DIORITE = id("blocks/diorite");
        public static final class_2960 ANDESITE = id("blocks/andesite");
        public static final class_2960 DEEPSLATE = id("blocks/deepslate");
        
        // Dirt & Grass
        public static final class_2960 DIRT = id("blocks/dirt");
        public static final class_2960 GRASS_BLOCK = id("blocks/grass_block");
        public static final class_2960 GRAVEL = id("blocks/gravel");
        public static final class_2960 SAND = id("blocks/sand");
        public static final class_2960 CLAY = id("blocks/clay");
        
        // Trees
        public static final class_2960 OAK_LEAVES = id("blocks/oak_leaves");
        public static final class_2960 SPRUCE_LEAVES = id("blocks/spruce_leaves");
        public static final class_2960 BIRCH_LEAVES = id("blocks/birch_leaves");
        public static final class_2960 JUNGLE_LEAVES = id("blocks/jungle_leaves");
        public static final class_2960 ACACIA_LEAVES = id("blocks/acacia_leaves");
        public static final class_2960 DARK_OAK_LEAVES = id("blocks/dark_oak_leaves");
        public static final class_2960 AZALEA_LEAVES = id("blocks/azalea_leaves");
        public static final class_2960 FLOWERING_AZALEA_LEAVES = id("blocks/flowering_azalea_leaves");
        public static final class_2960 MANGROVE_LEAVES = id("blocks/mangrove_leaves");
        public static final class_2960 CHERRY_LEAVES = id("blocks/cherry_leaves");
        
        // Crops
        public static final class_2960 WHEAT = id("blocks/wheat");
        public static final class_2960 CARROTS = id("blocks/carrots");
        public static final class_2960 POTATOES = id("blocks/potatoes");
        public static final class_2960 BEETROOTS = id("blocks/beetroots");
        public static final class_2960 MELON = id("blocks/melon");
        public static final class_2960 PUMPKIN = id("blocks/pumpkin");
        
        // Special
        public static final class_2960 GLOWSTONE = id("blocks/glowstone");
        public static final class_2960 SEA_LANTERN = id("blocks/sea_lantern");
        public static final class_2960 BOOKSHELF = id("blocks/bookshelf");
        public static final class_2960 SPAWNER = id("blocks/spawner");
        
        /**
         * Tworzy custom identifier dla bloku
         */
        public static class_2960 custom(String namespace, String path) {
            return new class_2960(namespace, "blocks/" + path);
        }
        
        /**
         * Tworzy minecraft identifier dla bloku
         */
        public static class_2960 of(String blockName) {
            return id("blocks/" + blockName);
        }
    }
    
    // ========== MOBY ==========
    public static class Entities {
        // Passive mobs
        public static final class_2960 PIG = id("entities/pig");
        public static final class_2960 COW = id("entities/cow");
        public static final class_2960 SHEEP = id("entities/sheep");
        public static final class_2960 CHICKEN = id("entities/chicken");
        public static final class_2960 RABBIT = id("entities/rabbit");
        public static final class_2960 HORSE = id("entities/horse");
        public static final class_2960 DONKEY = id("entities/donkey");
        public static final class_2960 LLAMA = id("entities/llama");
        public static final class_2960 MOOSHROOM = id("entities/mooshroom");
        public static final class_2960 PANDA = id("entities/panda");
        public static final class_2960 FOX = id("entities/fox");
        public static final class_2960 CAT = id("entities/cat");
        public static final class_2960 PARROT = id("entities/parrot");
        public static final class_2960 WOLF = id("entities/wolf");
        public static final class_2960 POLAR_BEAR = id("entities/polar_bear");
        
        // Hostile mobs
        public static final class_2960 ZOMBIE = id("entities/zombie");
        public static final class_2960 SKELETON = id("entities/skeleton");
        public static final class_2960 CREEPER = id("entities/creeper");
        public static final class_2960 SPIDER = id("entities/spider");
        public static final class_2960 CAVE_SPIDER = id("entities/cave_spider");
        public static final class_2960 ENDERMAN = id("entities/enderman");
        public static final class_2960 WITCH = id("entities/witch");
        public static final class_2960 BLAZE = id("entities/blaze");
        public static final class_2960 GHAST = id("entities/ghast");
        public static final class_2960 MAGMA_CUBE = id("entities/magma_cube");
        public static final class_2960 SLIME = id("entities/slime");
        public static final class_2960 SILVERFISH = id("entities/silverfish");
        public static final class_2960 GUARDIAN = id("entities/guardian");
        public static final class_2960 ELDER_GUARDIAN = id("entities/elder_guardian");
        public static final class_2960 SHULKER = id("entities/shulker");
        public static final class_2960 PHANTOM = id("entities/phantom");
        public static final class_2960 DROWNED = id("entities/drowned");
        public static final class_2960 HUSK = id("entities/husk");
        public static final class_2960 STRAY = id("entities/stray");
        public static final class_2960 WITHER_SKELETON = id("entities/wither_skeleton");
        public static final class_2960 ZOMBIE_VILLAGER = id("entities/zombie_villager");
        public static final class_2960 PILLAGER = id("entities/pillager");
        public static final class_2960 VINDICATOR = id("entities/vindicator");
        public static final class_2960 EVOKER = id("entities/evoker");
        public static final class_2960 RAVAGER = id("entities/ravager");
        public static final class_2960 VEX = id("entities/vex");
        
        // Bosses
        public static final class_2960 ENDER_DRAGON = id("entities/ender_dragon");
        public static final class_2960 WITHER = id("entities/wither");
        public static final class_2960 WARDEN = id("entities/warden");
        
        // Water mobs
        public static final class_2960 SQUID = id("entities/squid");
        public static final class_2960 GLOW_SQUID = id("entities/glow_squid");
        public static final class_2960 DOLPHIN = id("entities/dolphin");
        public static final class_2960 TURTLE = id("entities/turtle");
        public static final class_2960 COD = id("entities/cod");
        public static final class_2960 SALMON = id("entities/salmon");
        public static final class_2960 TROPICAL_FISH = id("entities/tropical_fish");
        public static final class_2960 PUFFERFISH = id("entities/pufferfish");
        
        /**
         * Tworzy custom identifier dla moba
         */
        public static class_2960 custom(String namespace, String path) {
            return new class_2960(namespace, "entities/" + path);
        }
        
        /**
         * Tworzy minecraft identifier dla moba
         */
        public static class_2960 of(String entityName) {
            return id("entities/" + entityName);
        }
    }
    
    // ========== SKRZYNIE ==========
    public static class Chests {
        // Village chests
        public static final class_2960 VILLAGE_ARMORER = id("chests/village/village_armorer");
        public static final class_2960 VILLAGE_BUTCHER = id("chests/village/village_butcher");
        public static final class_2960 VILLAGE_CARTOGRAPHER = id("chests/village/village_cartographer");
        public static final class_2960 VILLAGE_DESERT_HOUSE = id("chests/village/village_desert_house");
        public static final class_2960 VILLAGE_FISHER = id("chests/village/village_fisher");
        public static final class_2960 VILLAGE_FLETCHER = id("chests/village/village_fletcher");
        public static final class_2960 VILLAGE_MASON = id("chests/village/village_mason");
        public static final class_2960 VILLAGE_PLAINS_HOUSE = id("chests/village/village_plains_house");
        public static final class_2960 VILLAGE_SAVANNA_HOUSE = id("chests/village/village_savanna_house");
        public static final class_2960 VILLAGE_SHEPHERD = id("chests/village/village_shepherd");
        public static final class_2960 VILLAGE_SNOWY_HOUSE = id("chests/village/village_snowy_house");
        public static final class_2960 VILLAGE_TAIGA_HOUSE = id("chests/village/village_taiga_house");
        public static final class_2960 VILLAGE_TANNERY = id("chests/village/village_tannery");
        public static final class_2960 VILLAGE_TEMPLE = id("chests/village/village_temple");
        public static final class_2960 VILLAGE_TOOLSMITH = id("chests/village/village_toolsmith");
        public static final class_2960 VILLAGE_WEAPONSMITH = id("chests/village/village_weaponsmith");
        
        // Dungeon chests
        public static final class_2960 SIMPLE_DUNGEON = id("chests/simple_dungeon");
        public static final class_2960 ABANDONED_MINESHAFT = id("chests/abandoned_mineshaft");
        public static final class_2960 BURIED_TREASURE = id("chests/buried_treasure");
        public static final class_2960 DESERT_PYRAMID = id("chests/desert_pyramid");
        public static final class_2960 JUNGLE_TEMPLE = id("chests/jungle_temple");
        public static final class_2960 IGLOO_CHEST = id("chests/igloo_chest");
        public static final class_2960 PILLAGER_OUTPOST = id("chests/pillager_outpost");
        public static final class_2960 SHIPWRECK_MAP = id("chests/shipwreck_map");
        public static final class_2960 SHIPWRECK_SUPPLY = id("chests/shipwreck_supply");
        public static final class_2960 SHIPWRECK_TREASURE = id("chests/shipwreck_treasure");
        public static final class_2960 UNDERWATER_RUIN_BIG = id("chests/underwater_ruin_big");
        public static final class_2960 UNDERWATER_RUIN_SMALL = id("chests/underwater_ruin_small");
        public static final class_2960 WOODLAND_MANSION = id("chests/woodland_mansion");
        
        // Stronghold chests
        public static final class_2960 STRONGHOLD_CORRIDOR = id("chests/stronghold_corridor");
        public static final class_2960 STRONGHOLD_CROSSING = id("chests/stronghold_crossing");
        public static final class_2960 STRONGHOLD_LIBRARY = id("chests/stronghold_library");
        
        // Nether chests
        public static final class_2960 BASTION_BRIDGE = id("chests/bastion_bridge");
        public static final class_2960 BASTION_HOGLIN_STABLE = id("chests/bastion_hoglin_stable");
        public static final class_2960 BASTION_OTHER = id("chests/bastion_other");
        public static final class_2960 BASTION_TREASURE = id("chests/bastion_treasure");
        public static final class_2960 NETHER_BRIDGE = id("chests/nether_bridge");
        
        // End chests
        public static final class_2960 END_CITY_TREASURE = id("chests/end_city_treasure");
        
        /**
         * Tworzy custom identifier dla skrzyni
         */
        public static class_2960 custom(String namespace, String path) {
            return new class_2960(namespace, "chests/" + path);
        }
        
        /**
         * Tworzy minecraft identifier dla skrzyni
         */
        public static class_2960 of(String chestName) {
            return id("chests/" + chestName);
        }
    }
    
    // ========== FISHING ==========
    public static class Fishing {
        public static final class_2960 FISH = id("gameplay/fishing/fish");
        public static final class_2960 TREASURE = id("gameplay/fishing/treasure");
        public static final class_2960 JUNK = id("gameplay/fishing/junk");
        
        /**
         * Tworzy custom fishing loot table
         */
        public static class_2960 custom(String namespace, String path) {
            return new class_2960(namespace, "gameplay/fishing/" + path);
        }
    }
    
    // ========== ARCHAEOLOGY ==========
    public static class Archaeology {
        public static final class_2960 DESERT_PYRAMID = id("archaeology/desert_pyramid");
        public static final class_2960 DESERT_WELL = id("archaeology/desert_well");
        public static final class_2960 OCEAN_RUIN_COLD = id("archaeology/ocean_ruin_cold");
        public static final class_2960 OCEAN_RUIN_WARM = id("archaeology/ocean_ruin_warm");
        public static final class_2960 TRAIL_RUINS_COMMON = id("archaeology/trail_ruins_common");
        public static final class_2960 TRAIL_RUINS_RARE = id("archaeology/trail_ruins_rare");
    }
    
    // ========== HELPER METHODS ==========
    
    /**
     * Tworzy Identifier z namespace "minecraft"
     */
    private static class_2960 id(String path) {
        return new class_2960("minecraft", path);
    }
    
    /**
     * Tworzy custom loot table identifier
     */
    public static class_2960 custom(String namespace, String path) {
        return new class_2960(namespace, path);
    }
    
    /**
     * Sprawdza czy ścieżka pasuje do patternu (wildcard support)
     */
    public static boolean matches(class_2960 id, String pattern) {
        String idString = id.toString();
        String regex = pattern.replace("*", ".*").replace("?", ".");
        return idString.matches(regex);
    }
}
