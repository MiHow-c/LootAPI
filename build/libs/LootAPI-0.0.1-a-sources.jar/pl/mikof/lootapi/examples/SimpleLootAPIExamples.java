package pl.mikof.lootapi.examples;

import net.minecraft.class_1802;
import pl.mikof.lootapi.*;

/**
 * Przykłady użycia Loot API z nową klasą LootTables
 * Pokazuje jak łatwo używać predefiniowanych ścieżek
 */
public class SimpleLootAPIExamples {
    
    public static void registerExamples() {
        
        // ========== ŁATWY SPOSÓB - UŻYJ LootTables ==========
        
        // 1. Dodaj diament do coal ore - ŁATWY SPOSÓB!
        LootTableAPI.addItemToTable(
            LootTables.Blocks.COAL_ORE,  // Zamiast: new Identifier("minecraft", "blocks/coal_ore")
            class_1802.field_8477,
            5
        );
        
        // 2. Zombie dropuje złoto
        LootTableAPI.addItemWithCount(
            LootTables.Entities.ZOMBIE,  // Łatwe!
            class_1802.field_8695,
            10, 2, 5
        );
        
        // 3. Creeper dropuje TNT
        LootTableAPI.addItemToTable(
            LootTables.Entities.CREEPER,
            class_1802.field_8626,
            25
        );
        
        // 4. Skrzynia w End City
        LootTableAPI.addItemToTable(
            LootTables.Chests.END_CITY_TREASURE,
            class_1802.field_8833,
            5
        );
        
        // 5. Podwój dropy ze szkieleta
        LootTableAPI.multiplyDrops(
            LootTables.Entities.SKELETON,
            2.0f
        );
        
        // 6. Zamień węgiel na diamenty
        LootTableAPI.replaceItem(
            LootTables.Blocks.COAL_ORE,
            class_1802.field_8713,
            class_1802.field_8477
        );
        
        // 7. Dodaj emerald do wszystkich rud (wildcard!)
        LootTableAPI.addToMatching(
            "minecraft:blocks/*_ore",  // Wszystkie rudy!
            class_1802.field_8687,
            3
        );
        
        // 8. Grupa itemów dla skrzyni
        WeightedItemGroup treasureGroup = new WeightedItemGroup()
            .add(class_1802.field_8477, 10)
            .add(class_1802.field_8687, 20)
            .add(class_1802.field_22020, 5);
        
        LootTableAPI.addWeightedGroup(
            LootTables.Chests.BURIED_TREASURE,
            treasureGroup
        );

        
        // 10. Custom mod ore - też łatwe!
        LootTableAPI.addItemToTable(
            LootTables.Blocks.custom("yourmod", "mythril_ore"),
            class_1802.field_8477,
            50
        );
        
        // ========== PORÓWNANIE ==========
        
        // STARY SPOSÓB (nadal działa):
        // new Identifier("minecraft", "blocks/diamond_ore")
        
        // NOWY SPOSÓB (łatwiejszy):
        // LootTables.Blocks.DIAMOND_ORE
        
        // ========== WIĘCEJ PRZYKŁADÓW ==========
        
        // Wszystkie liście dropują jabłka
        LootTableAPI.addItemToTable(LootTables.Blocks.OAK_LEAVES, class_1802.field_8279, 10);
        LootTableAPI.addItemToTable(LootTables.Blocks.BIRCH_LEAVES, class_1802.field_8279, 10);
        LootTableAPI.addItemToTable(LootTables.Blocks.SPRUCE_LEAVES, class_1802.field_8279, 10);
        
        // Lub użyj bulk operations:
        LootTableAPI.addToMatching(
            "minecraft:blocks/*_leaves",
            class_1802.field_8463,
            1
        );
        
        // Boss dropy
        LootTableAPI.addItemToTable(
            LootTables.Entities.ENDER_DRAGON,
            class_1802.field_8840,
            100
        );
        
        LootTableAPI.addItemToTable(
            LootTables.Entities.WITHER,
            class_1802.field_8137,
            100
        );
        
        // Fishing treasure
        LootTableAPI.addItemToTable(
            LootTables.Fishing.TREASURE,
            class_1802.field_8547,
            5
        );
        
        // Village chests
        LootTableAPI.addItemToTable(
            LootTables.Chests.VILLAGE_WEAPONSMITH,
            class_1802.field_22022,
            2
        );
        
        // Nether fortress
        LootTableAPI.addItemToTable(
            LootTables.Chests.NETHER_BRIDGE,
            class_1802.field_22019,
            3
        );
    }
}
