package pl.mikof.lootapi.examples;

import net.minecraft.class_1802;
import net.minecraft.class_2960;
import pl.mikof.lootapi.*;

/**
 * Przykłady użycia wszystkich funkcji Loot API
 * WAŻNE: Te przykłady są wywoływane automatycznie przez LootAPI.onInitialize()
 */
public class LootAPIExamples {
    
    public static void registerExamples() {
        
        LootLogger.logInfo("Registering example modifications...");
        LootLogger.logEmptyLine();
        
        // ========== BLOKI - ORE DROPS ==========
        registerOreDrops();
        
        // ========== MOBY - ENTITY DROPS ==========
        registerEntityDrops();
        
        // ========== SKRZYNIE - CHEST LOOT ==========
        registerChestLoot();
        
        // ========== PODSUMOWANIE ==========
        showSummary();
    }
    
    private static void registerOreDrops() {
        LootLogger.logInfo("▸ ORE DROPS:");
        
        // 35% szansy na diament z iron ore
        LootTableAPI.addItemWithChance(
            new class_2960("minecraft", "blocks/iron_ore"),
            class_1802.field_8477,
            35
        );
        
        // Coal ore dropuje diamenty z Fortune
        LootTableAPI.addItemWithFortune(
            new class_2960("minecraft", "blocks/coal_ore"),
            class_1802.field_8477, 
            70, 1, 2
        );
        
        LootLogger.logInfo("  ✓ 2 ore modifications registered");
        LootLogger.logEmptyLine();
    }
    
    private static void registerEntityDrops() {
        LootLogger.logInfo("▸ ENTITY DROPS:");
        
        // Zombie: 50% szansy na 2-5 złota
        LootTableAPI.addItemWithChance(
            new class_2960("minecraft", "entities/zombie"),
            class_1802.field_8695,
            50, 2, 5
        );
        
        // Creeper: 10% szansy na TNT
        LootTableAPI.addItemWithChance(
            new class_2960("minecraft", "entities/creeper"),
            class_1802.field_8626,
            10
        );
        
        // Skeleton: 2x drop multiplier
        LootTableAPI.multiplyDrops(
            new class_2960("minecraft", "entities/skeleton"),
            2.0f
        );
        
        LootLogger.logInfo("  ✓ 3 entity modifications registered");
        LootLogger.logEmptyLine();
    }
    
    private static void registerChestLoot() {
        LootLogger.logInfo("▸ CHEST LOOT:");
        
        // End City treasure - grupa itemów
        WeightedItemGroup treasureGroup = new WeightedItemGroup()
            .add(class_1802.field_8477, 30)
            .add(class_1802.field_8687, 20)
            .add(class_1802.field_22020, 5);
        
        LootTableAPI.addWeightedGroup(
            new class_2960("minecraft", "chests/end_city_treasure"), 
            treasureGroup
        );
        
        LootLogger.logInfo("  ✓ 1 chest modification registered");
        LootLogger.logEmptyLine();
    }
    
    private static void showSummary() {
        LootLogger.logSeparator();
        LootLogger.logInfo("SUMMARY:");
        LootLogger.logInfo("  • Iron ore → 35% diamonds");
        LootLogger.logInfo("  • Coal ore → diamonds with Fortune");
        LootLogger.logInfo("  • Zombie → 50% for 2-5 gold");
        LootLogger.logInfo("  • Creeper → 10% TNT");
        LootLogger.logInfo("  • Skeleton → 2x drops");
        LootLogger.logInfo("  • End City → extra treasure");
        LootLogger.logSeparator();
        LootLogger.logEmptyLine();
        
        LootLogger.logHighlight("TIP: Use addItemWithChance() for exact percentages!");
        LootLogger.logEmptyLine();
    }
}
