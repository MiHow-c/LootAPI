package pl.mikof.lootapi.examples;

import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_77;
import pl.mikof.lootapi.*;

/**
 * Przykłady tworzenia CAŁKOWICIE NOWYCH loot tables
 */
public class NewLootTableExamples {
    
    public static void registerNewLootTables() {
        
        // ========== SPOSÓB 1: SZYBKI (Quick Methods) ==========
        
        // 1. Pojedynczy item - super proste!
        LootTableBuilder.quickSingle(
            new class_2960("yourmod", "blocks/simple_ore"),
            class_1802.field_8477
        );
        
        // 2. Wiele itemów z równymi szansami
        LootTableBuilder.quickBalanced(
            new class_2960("yourmod", "chests/starter_chest"),
            class_1802.field_8371,
            class_1802.field_8403,
            class_1802.field_8229,
            class_1802.field_8810
        );
        
        // 3. Ore z określoną ilością dropów
        LootTableBuilder.quickOre(
            new class_2960("yourmod", "blocks/copper_ore"),
            class_1802.field_33401,
            2,  // min drops
            5   // max drops
        );
        
        // ========== SPOSÓB 2: BUILDER (Bardziej kontroli) ==========
        
        // 4. Custom ore z różnymi dropami
        LootTableBuilder.create("yourmod", "blocks/mythril_ore")
            .addItem(class_1802.field_8477, 70)
            .addItem(class_1802.field_8687, 20)
            .addItem(class_1802.field_22021, 10)
            .register();
        
        // 5. Chest z wieloma itemami i ilościami
        LootTableBuilder.create("yourmod", "chests/treasure_chest")
            .addItem(class_1802.field_8477, 50, 1, 3)
            .addItem(class_1802.field_8695, 80, 5, 10)
            .addItem(class_1802.field_8687, 30, 2, 5)
            .register();
        
        // 6. Mob loot z pool'ami
        LootTableBuilder.create("yourmod", "entities/custom_mob")
            .pool(1)
                .item(class_1802.field_8511, 80)
                .item(class_1802.field_8606, 20)
            .endPool()
            .pool(1)
                .item(class_1802.field_8477, 5)
                .item(class_1802.field_8687, 10)
                .item(class_1802.field_8695, 85)
            .endPool()
            .register();
        
        // 7. Chest z losową liczbą itemów
        LootTableBuilder.create("yourmod", "chests/random_chest")
            .pool(3, 7)
                .item(class_1802.field_8620, 40)
                .item(class_1802.field_8695, 30)
                .item(class_1802.field_8477, 20)
                .item(class_1802.field_8687, 10)
            .endPool()
            .register();
        
        // ========== SPOSÓB 3: Z GRUPAMI ==========
        
        // 8. Użyj WeightedItemGroup
        WeightedItemGroup commonItems = new WeightedItemGroup()
            .add(class_1802.field_8620, 50)
            .add(class_1802.field_8695, 30)
            .add(class_1802.field_8713, 20);
        
        WeightedItemGroup rareItems = new WeightedItemGroup()
            .add(class_1802.field_8477, 60)
            .add(class_1802.field_8687, 30)
            .add(class_1802.field_22021, 10);
        
        LootTableBuilder.create("yourmod", "chests/epic_chest")
            .addGroup(commonItems, 5)
            .addGroup(rareItems, 2)
            .register();
        
        // ========== SPOSÓB 4: ZAAWANSOWANY ==========
        
        // 9. Custom pool z warunkami
        LootTableBuilder.create("yourmod", "entities/night_mob")
            .pool(1)
                .item(class_1802.field_8634, 100)
            .endPool()
            .customPool(pool -> {
                pool.method_352(class_44.method_32448(2))
                    .method_351(class_77.method_411(class_1802.field_8614).method_437(50))
                    .method_351(class_77.method_411(class_1802.field_8070).method_437(50));
            })
            .register();
        
        // 10. Fishing loot table
        LootTableBuilder.create("yourmod", "gameplay/fishing/custom_fishing")
            .pool(1)
                .item(class_1802.field_8429, 60)
                .item(class_1802.field_8209, 25)
                .item(class_1802.field_8846, 10)
                .item(class_1802.field_8323, 5)
            .endPool()
            .register();
        
        // 11. Boss mob
        LootTableBuilder.create("yourmod", "entities/custom_boss")
            .addItem(class_1802.field_8137, 100)
            .addItem(class_1802.field_8712, 50)
            .addItem(class_1802.field_8833, 25, 1, 1)
            .pool(5, 10)
                .item(class_1802.field_8477, 30)
                .item(class_1802.field_8687, 30)
                .item(class_1802.field_22020, 20)
                .item(class_1802.field_8367, 20)
            .endPool()
            .register();
    }
    
    // ========== HELPER METHODS ==========
    
    public static void createCustomOre(String modId, String oreName, 
                                       net.minecraft.class_1792 rawItem, 
                                       int minDrops, int maxDrops) {
        LootTableBuilder.create(modId, "blocks/" + oreName)
            .pool(1)
                .item(rawItem, 100, minDrops, maxDrops)
            .endPool()
            .register();
    }
    
    public static void createCustomMob(String modId, String mobName, 
                                       net.minecraft.class_1792 commonDrop, 
                                       net.minecraft.class_1792 rareDrop) {
        LootTableBuilder.create(modId, "entities/" + mobName)
            .addItem(commonDrop, 80, 0, 2)
            .addItem(rareDrop, 20, 1, 1)
            .register();
    }
    
    public static void createCustomChest(String modId, String chestName, 
                                         WeightedItemGroup items) {
        LootTableBuilder.create(modId, "chests/" + chestName)
            .addGroup(items, 5)
            .register();
    }
}
