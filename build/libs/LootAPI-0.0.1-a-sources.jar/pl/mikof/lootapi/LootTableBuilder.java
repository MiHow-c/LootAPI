package pl.mikof.lootapi;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

/**
 * Builder do łatwego tworzenia nowych loot tables
 */
public class LootTableBuilder {
    private final class_2960 tableId;
    private final class_52.class_53 builder;
    
    private LootTableBuilder(class_2960 tableId) {
        this.tableId = tableId;
        this.builder = class_52.method_324();
    }
    
    /**
     * Rozpoczyna tworzenie nowego loot table
     */
    public static LootTableBuilder create(class_2960 tableId) {
        return new LootTableBuilder(tableId);
    }
    
    /**
     * Rozpoczyna tworzenie nowego loot table z łatwiejszym identyfikatorem
     */
    public static LootTableBuilder create(String namespace, String path) {
        return new LootTableBuilder(new class_2960(namespace, path));
    }
    
    /**
     * Dodaje prosty pool z jednym itemem
     * @param item Item do dodania
     * @param weight Waga (szansa)
     * @return this builder
     */
    public LootTableBuilder addItem(class_1792 item, int weight) {
        class_55.class_56 pool = class_55.method_347()
            .method_352(class_44.method_32448(1))
            .method_351(class_77.method_411(item).method_437(weight));
        builder.method_336(pool);
        return this;
    }
    
    /**
     * Dodaje item z określoną ilością
     * @param item Item do dodania
     * @param weight Waga
     * @param minCount Minimalna ilość
     * @param maxCount Maksymalna ilość
     * @return this builder
     */
    public LootTableBuilder addItem(class_1792 item, int weight, int minCount, int maxCount) {
        class_55.class_56 pool = class_55.method_347()
            .method_352(class_44.method_32448(1))
            .method_351(class_77.method_411(item)
                .method_437(weight)
                .method_438(net.minecraft.class_141.method_621(
                    class_5662.method_32462(minCount, maxCount))));
        builder.method_336(pool);
        return this;
    }
    
    /**
     * Rozpoczyna nowy pool z wieloma itemami
     * @param rolls Liczba losowań (ile itemów wypadnie)
     * @return PoolBuilder
     */
    public PoolBuilder pool(int rolls) {
        return new PoolBuilder(this, rolls);
    }
    
    /**
     * Rozpoczyna nowy pool z losową liczbą losowań
     * @param minRolls Minimalna liczba losowań
     * @param maxRolls Maksymalna liczba losowań
     * @return PoolBuilder
     */
    public PoolBuilder pool(int minRolls, int maxRolls) {
        return new PoolBuilder(this, minRolls, maxRolls);
    }
    
    /**
     * Dodaje grupę itemów jako pool
     * @param group Grupa itemów z wagami
     * @return this builder
     */
    public LootTableBuilder addGroup(WeightedItemGroup group) {
        class_55.class_56 pool = class_55.method_347()
            .method_352(class_44.method_32448(1));
        
        group.getItems().forEach((item, weight) -> {
            pool.method_351(class_77.method_411(item).method_437(weight));
        });
        
        builder.method_336(pool);
        return this;
    }
    
    /**
     * Dodaje grupę itemów z określoną liczbą losowań
     * @param group Grupa itemów
     * @param rolls Liczba losowań
     * @return this builder
     */
    public LootTableBuilder addGroup(WeightedItemGroup group, int rolls) {
        class_55.class_56 pool = class_55.method_347()
            .method_352(class_44.method_32448(rolls));
        
        group.getItems().forEach((item, weight) -> {
            pool.method_351(class_77.method_411(item).method_437(weight));
        });
        
        builder.method_336(pool);
        return this;
    }
    
    /**
     * Dodaje custom pool używając Consumer
     * @param poolModifier Funkcja modyfikująca pool
     * @return this builder
     */
    public LootTableBuilder customPool(java.util.function.Consumer<class_55.class_56> poolModifier) {
        class_55.class_56 pool = class_55.method_347();
        poolModifier.accept(pool);
        builder.method_336(pool);
        return this;
    }
    
    /**
     * Rejestruje loot table w API
     */
    public void register() {
        LootTableAPI.createLootTable(tableId, b -> {
            // Kopiuj wszystkie pool'e z naszego buildera
        });
        LootTableAPI.registerModifier(tableId, b -> builder.method_338());
        LootTableAPI.LOGGER.info("Registered new loot table: {}", tableId);
    }
    
    /**
     * Zwraca zbudowany loot table (bez rejestracji)
     */
    public class_52 build() {
        return builder.method_338();
    }
    
    /**
     * Zwraca ID tego loot table
     */
    public class_2960 getId() {
        return tableId;
    }
    
    // ========== POOL BUILDER ==========
    
    /**
     * Builder do tworzenia pool'i z wieloma itemami
     */
    public static class PoolBuilder {
        private final LootTableBuilder parent;
        private final class_55.class_56 pool;
        
        private PoolBuilder(LootTableBuilder parent, int rolls) {
            this.parent = parent;
            this.pool = class_55.method_347()
                .method_352(class_44.method_32448(rolls));
        }
        
        private PoolBuilder(LootTableBuilder parent, int minRolls, int maxRolls) {
            this.parent = parent;
            this.pool = class_55.method_347()
                .method_352(class_5662.method_32462(minRolls, maxRolls));
        }
        
        /**
         * Dodaje item do pool'a
         */
        public PoolBuilder item(class_1792 item, int weight) {
            pool.method_351(class_77.method_411(item).method_437(weight));
            return this;
        }
        
        /**
         * Dodaje item z określoną ilością do pool'a
         */
        public PoolBuilder item(class_1792 item, int weight, int minCount, int maxCount) {
            pool.method_351(class_77.method_411(item)
                .method_437(weight)
                .method_438(net.minecraft.class_141.method_621(
                    class_5662.method_32462(minCount, maxCount))));
            return this;
        }
        
        /**
         * Dodaje warunek do pool'a
         */
        public PoolBuilder condition(net.minecraft.class_5341.class_210 condition) {
            pool.method_356(condition);
            return this;
        }
        
        /**
         * Kończy tworzenie pool'a i wraca do głównego buildera
         */
        public LootTableBuilder endPool() {
            parent.builder.method_336(pool);
            return parent;
        }
    }
    
    // ========== QUICK BUILD METHODS ==========
    
    /**
     * Szybko tworzy loot table z pojedynczym itemem
     */
    public static void quickSingle(class_2960 tableId, class_1792 item) {
        create(tableId)
            .addItem(item, 100)
            .register();
    }
    
    /**
     * Szybko tworzy loot table z wieloma itemami (równe szanse)
     */
    public static void quickBalanced(class_2960 tableId, class_1792... items) {
        LootTableBuilder builder = create(tableId);
        int weightPerItem = 100 / items.length;
        
        for (class_1792 item : items) {
            builder.addItem(item, weightPerItem);
        }
        
        builder.register();
    }
    
    /**
     * Szybko tworzy ore loot table
     */
    public static void quickOre(class_2960 tableId, class_1792 rawOre, int minDrops, int maxDrops) {
        create(tableId)
            .pool(1)
                .item(rawOre, 100, minDrops, maxDrops)
            .endPool()
            .register();
    }
}
