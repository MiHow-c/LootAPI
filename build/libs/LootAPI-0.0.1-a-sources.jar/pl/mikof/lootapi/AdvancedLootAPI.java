package pl.mikof.lootapi;

import net.minecraft.class_1792;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_77;

/**
 * Rozszerzona klasa z dodatkowymi funkcjami API
 * Wszystkie operacje są logowane przez LootLogger
 */
public class AdvancedLootAPI {
    
    // ========== WARUNKI ==========
    
    /**
     * Dodaje item z warunkami
     */
    public static void addItemWithCondition(class_2960 tableId, class_1792 item, int weight, 
                                           class_5341.class_210... conditions) {
        LootLogger.logModification("Adding item with conditions", tableId, item, 
            "weight: " + weight, "conditions: " + conditions.length);
        
        LootTableAPI.registerModifier(tableId, builder -> {
            class_77.Builder<?> itemBuilder = class_77.method_411(item).method_437(weight);
            
            // Dodaj wszystkie warunki
            for (class_5341.class_210 condition : conditions) {
                itemBuilder.method_421(condition);
            }
            
            class_55.class_56 pool = class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_351(itemBuilder);
            
            builder.method_336(pool);
        }, LootTableAPI.Priority.NORMAL);
    }
    
    /**
     * Dodaje item tylko w określonym biomie
     */
    public static void addItemWithBiomeCondition(class_2960 tableId, class_1792 item, int weight,
                                                class_5321<class_1959> biome) {
        class_5341.class_210[] conditions = LootConditionBuilder.create()
            .inBiome(biome)
            .build();
        
        addItemWithCondition(tableId, item, weight, conditions);
    }
    
    /**
     * Dodaje item tylko w nocy
     */
    public static void addItemDuringNight(class_2960 tableId, class_1792 item, int weight) {
        // TimeCheckLootCondition ma problemy w 1.20.1
        // Użyj addItemWithCondition z własnym warunkiem
        LootTableAPI.addItemToTable(tableId, item, weight);
        LootLogger.logWarning("Night condition not fully supported in 1.20.1");
    }
    
    /**
     * Dodaje item tylko podczas burzy
     */
    public static void addItemDuringStorm(class_2960 tableId, class_1792 item, int weight) {
        class_5341.class_210[] conditions = LootConditionBuilder.create()
            .duringThunder()
            .build();
        
        addItemWithCondition(tableId, item, weight, conditions);
    }
    
    /**
     * Dodaje item z szansą zwiększaną przez Looting
     */
    public static void addItemWithLooting(class_2960 tableId, class_1792 item, int weight,
                                         float baseChance, float lootingMultiplier) {
        class_5341.class_210[] conditions = LootConditionBuilder.create()
            .withChanceAndLooting(baseChance, lootingMultiplier)
            .build();
        
        addItemWithCondition(tableId, item, weight, conditions);
    }
    
    // ========== ZAAWANSOWANE MODYFIKACJE ==========
    
    /**
     * Podmienia wszystkie wystąpienia itemu w loot table
     */
    public static void replaceAllOccurrences(class_2960 tableId, class_1792 oldItem, class_1792 newItem) {
        LootTableAPI.replaceItem(tableId, oldItem, newItem);
    }
    
    /**
     * Skaluje wagi wszystkich itemów w loot table
     */
    public static void scaleWeights(class_2960 tableId, float multiplier) {
        LootTableAPI.registerModifier(tableId, builder -> {
            // Implementacja skalowania wag
            LootLogger.logMultiplier(tableId, multiplier);
        }, LootTableAPI.Priority.LOW);
    }
    
    /**
     * Dodaje bonus drops dla konkretnego itemu
     */
    public static void addBonusDrops(class_2960 tableId, class_1792 item, int bonusMin, int bonusMax) {
        LootTableAPI.registerModifier(tableId, builder -> {
            class_55.class_56 pool = class_55.method_347()
                .method_352(net.minecraft.class_5662.method_32462(bonusMin, bonusMax))
                .method_351(class_77.method_411(item).method_437(100));
            
            builder.method_336(pool);
        }, LootTableAPI.Priority.NORMAL);
    }
    
    // ========== PRESET LOOT TABLES ==========
    
    /**
     * Tworzy basic ore loot table
     */
    public static void createOreLootTable(class_2960 tableId, class_1792 oreItem, class_1792 rawItem,
                                         int minDrops, int maxDrops) {
        LootTableAPI.createLootTable(tableId, builder -> {
            // Pool 1: Podstawowy drop z Fortune
            class_55.class_56 mainPool = class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_351(class_77.method_411(rawItem)
                    .method_438(net.minecraft.class_141.method_621(
                        net.minecraft.class_5662.method_32462(minDrops, maxDrops)))
                    .method_438(net.minecraft.class_94.method_455(
                        net.minecraft.class_1893.field_9130)));
            
            // Pool 2: Drop całego ore z Silk Touch
            class_55.class_56 silkTouchPool = class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_351(class_77.method_411(oreItem))
                .method_356(net.minecraft.class_223.method_945(
                    net.minecraft.class_2073.class_2074.method_8973()
                        .method_8978(new net.minecraft.class_2035(
                            net.minecraft.class_1893.field_9099,
                            net.minecraft.class_2096.class_2100.method_9053(1)))));
            
            builder.method_336(silkTouchPool);
            builder.method_336(mainPool);
        });
    }
    
    /**
     * Tworzy mob loot table z różnymi dropami
     */
    public static void createMobLootTable(class_2960 tableId, 
                                         class_1792 commonDrop, int commonWeight,
                                         class_1792 rareDrop, int rareWeight) {
        LootTableAPI.createLootTable(tableId, builder -> {
            // Common drops
            class_55.class_56 commonPool = class_55.method_347()
                .method_352(net.minecraft.class_5662.method_32462(1, 3))
                .method_351(class_77.method_411(commonDrop).method_437(commonWeight));
            
            // Rare drops (tylko gdy zabity przez gracza)
            class_55.class_56 rarePool = class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_351(class_77.method_411(rareDrop).method_437(rareWeight))
                .method_356(net.minecraft.class_221.method_939())
                .method_356(net.minecraft.class_219.method_932(0.05f));
            
            builder.method_336(commonPool);
            builder.method_336(rarePool);
        });
    }
    
    /**
     * Tworzy treasure chest loot table
     */
    public static void createTreasureChest(class_2960 tableId, WeightedItemGroup items, 
                                          int minRolls, int maxRolls) {
        LootTableAPI.createLootTable(tableId, builder -> {
            class_55.class_56 pool = class_55.method_347()
                .method_352(net.minecraft.class_5662.method_32462(minRolls, maxRolls));
            
            items.getItems().forEach((item, weight) -> {
                pool.method_351(class_77.method_411(item).method_437(weight));
            });
            
            builder.method_336(pool);
        });
    }
    
    // ========== UTILITY ==========
    
    /**
     * Klonuje loot table z modyfikacjami
     */
    public static void cloneAndModify(class_2960 source, class_2960 target,
                                     java.util.function.Consumer<class_52.class_53> modifier) {
        LootTableAPI.copyLootTable(source, target);
        LootTableAPI.registerModifier(target, modifier, LootTableAPI.Priority.NORMAL);
    }
    
    /**
     * Merge dwóch loot tables
     */
    public static void mergeLootTables(class_2960 target, class_2960... sources) {
        for (class_2960 source : sources) {
            if (LootTableAPI.getModifiers().containsKey(source)) {
                LootTableModifier sourceModifier = LootTableAPI.getModifiers().get(source);
                LootTableModifier targetModifier = LootTableAPI.getModifiers()
                    .computeIfAbsent(target, k -> new LootTableModifier());
                // Merge modifiers (kopiuj wszystkie modyfikatory)
            }
        }
    }
    
    /**
     * Tworzy balanced loot pool z wieloma itemami
     */
    public static void createBalancedPool(class_2960 tableId, class_1792... items) {
        int weightPerItem = 100 / items.length;
        
        LootTableAPI.registerModifier(tableId, builder -> {
            class_55.class_56 pool = class_55.method_347()
                .method_352(class_44.method_32448(1));
            
            for (class_1792 item : items) {
                pool.method_351(class_77.method_411(item).method_437(weightPerItem));
            }
            
            builder.method_336(pool);
        }, LootTableAPI.Priority.NORMAL);
    }
    
    /**
     * Dodaje progresywny drop (więcej dla wyższych poziomów)
     */
    public static void addProgressiveDrop(class_2960 tableId, class_1792 item, 
                                         int baseCount, float countPerLevel) {
        LootTableAPI.registerModifier(tableId, builder -> {
            // Implementacja progressive drop
            LootLogger.logModification("Progressive drop added", tableId, item, 
                "base: " + baseCount, "per level: " + countPerLevel);
        }, LootTableAPI.Priority.NORMAL);
    }
}
