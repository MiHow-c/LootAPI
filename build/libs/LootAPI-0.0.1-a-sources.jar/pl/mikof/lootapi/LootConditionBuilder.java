package pl.mikof.lootapi;

import net.minecraft.class_1893;
import net.minecraft.class_1959;
import net.minecraft.class_201;
import net.minecraft.class_205;
import net.minecraft.class_207;
import net.minecraft.class_2090;
import net.minecraft.class_219;
import net.minecraft.class_221;
import net.minecraft.class_223;
import net.minecraft.class_225;
import net.minecraft.class_227;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.loot.condition.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Builder do tworzenia warunków dla loot tables
 */
public class LootConditionBuilder {
    private final List<class_5341.class_210> conditions = new ArrayList<>();
    
    /**
     * Dodaje warunek Fortune enchantment
     */
    public LootConditionBuilder withFortune() {
        conditions.add(class_223.method_945(
            net.minecraft.class_2073.class_2074.method_8973()
                .method_8978(new net.minecraft.class_2035(
                    class_1893.field_9130, 
                    net.minecraft.class_2096.class_2100.method_9053(1)))
        ));
        return this;
    }
    
    /**
     * Dodaje warunek Silk Touch enchantment
     */
    public LootConditionBuilder withSilkTouch() {
        conditions.add(class_223.method_945(
            net.minecraft.class_2073.class_2074.method_8973()
                .method_8978(new net.minecraft.class_2035(
                    class_1893.field_9099, 
                    net.minecraft.class_2096.class_2100.method_9053(1)))
        ));
        return this;
    }
    
    /**
     * Dodaje warunek konkretnego poziomu enchantu
     */
    public LootConditionBuilder withEnchantmentLevel(net.minecraft.class_1887 enchantment, int minLevel) {
        conditions.add(class_223.method_945(
            net.minecraft.class_2073.class_2074.method_8973()
                .method_8978(new net.minecraft.class_2035(
                    enchantment, 
                    net.minecraft.class_2096.class_2100.method_9053(minLevel)))
        ));
        return this;
    }
    
    /**
     * Dodaje warunek biomu
     */
    public LootConditionBuilder inBiome(class_5321<class_1959> biome) {
        conditions.add(class_205.method_884(
            class_2090.class_2091.method_22484()
                .method_9024(biome)
        ));
        return this;
    }
    
    /**
     * Dodaje warunek pory dnia (dzień)
     * Uwaga: Funkcja wyłączona - problemy z kompatybilnością
     */
    public LootConditionBuilder duringDay() {
        // TimeCheckLootCondition ma problemy w 1.20.1
        // Użyj custom condition jeśli potrzebujesz
        return this;
    }
    
    /**
     * Dodaje warunek pory dnia (noc)
     * Uwaga: Funkcja wyłączona - problemy z kompatybilnością
     */
    public LootConditionBuilder duringNight() {
        // TimeCheckLootCondition ma problemy w 1.20.1
        // Użyj custom condition jeśli potrzebujesz
        return this;
    }
    
    /**
     * Dodaje warunek konkretnego czasu
     * Uwaga: Funkcja wyłączona - problemy z kompatybilnością
     */
    public LootConditionBuilder atTime(int minTime, int maxTime) {
        // TimeCheckLootCondition ma problemy w 1.20.1
        // Użyj custom condition jeśli potrzebujesz
        return this;
    }
    
    /**
     * Dodaje warunek pogody (deszcz)
     */
    public LootConditionBuilder duringRain() {
        conditions.add(class_227.method_35564().method_35565(true));
        return this;
    }
    
    /**
     * Dodaje warunek pogody (burza)
     */
    public LootConditionBuilder duringThunder() {
        conditions.add(class_227.method_35564().method_35567(true));
        return this;
    }
    
    /**
     * Dodaje warunek losowej szansy (0.0 - 1.0)
     */
    public LootConditionBuilder withChance(float chance) {
        conditions.add(class_219.method_932(chance));
        return this;
    }
    
    /**
     * Dodaje warunek losowej szansy z bonusem od Looting
     */
    public LootConditionBuilder withChanceAndLooting(float baseChance, float lootingMultiplier) {
        conditions.add(class_225.method_953(baseChance, lootingMultiplier));
        return this;
    }
    
    /**
     * Dodaje warunek że gracz zabił (dla mobów)
     */
    public LootConditionBuilder killedByPlayer() {
        conditions.add(class_221.method_939());
        return this;
    }
    
    /**
     * Dodaje warunek przeżycia eksplozji
     */
    public LootConditionBuilder survivedExplosion() {
        conditions.add(class_201.method_871());
        return this;
    }
    
    /**
     * Dodaje warunek wysokości (Y level)
     */
    public LootConditionBuilder atHeight(int minY, int maxY) {
        conditions.add(class_205.method_884(
            class_2090.class_2091.method_22484()
                .method_35278(net.minecraft.class_2096.class_2099.method_35285((float)minY, (float)maxY))
        ));
        return this;
    }
    
    /**
     * Dodaje custom warunek
     */
    public LootConditionBuilder custom(class_5341.class_210 condition) {
        conditions.add(condition);
        return this;
    }
    
    /**
     * Odwraca wszystkie warunki (NOT)
     */
    public LootConditionBuilder invert() {
        List<class_5341.class_210> inverted = new ArrayList<>();
        for (class_5341.class_210 condition : conditions) {
            inverted.add(class_207.method_889(condition));
        }
        conditions.clear();
        conditions.addAll(inverted);
        return this;
    }
    
    /**
     * Buduje tablicę warunków
     */
    public class_5341.class_210[] build() {
        return conditions.toArray(new class_5341.class_210[0]);
    }
    
    /**
     * Zwraca liczbę warunków
     */
    public int size() {
        return conditions.size();
    }
    
    /**
     * Sprawdza czy są jakieś warunki
     */
    public boolean isEmpty() {
        return conditions.isEmpty();
    }
    
    /**
     * Czyści wszystkie warunki
     */
    public void clear() {
        conditions.clear();
    }
    
    /**
     * Tworzy nowy builder
     */
    public static LootConditionBuilder create() {
        return new LootConditionBuilder();
    }
    
    // ========== PREDEFINIOWANE KOMBINACJE ==========
    
    /**
     * Warunek: Fortune enchant
     */
    public static class_5341.class_210[] FORTUNE() {
        return create().withFortune().build();
    }
    
    /**
     * Warunek: Silk Touch enchant
     */
    public static class_5341.class_210[] SILK_TOUCH() {
        return create().withSilkTouch().build();
    }
    
    /**
     * Warunek: Noc + burza
     */
    public static class_5341.class_210[] STORMY_NIGHT() {
        return create().duringNight().duringThunder().build();
    }
    
    /**
     * Warunek: Zabity przez gracza + szansa
     */
    public static class_5341.class_210[] RARE_PLAYER_KILL(float chance) {
        return create().killedByPlayer().withChance(chance).build();
    }
    
    @Override
    public String toString() {
        return String.format("LootConditionBuilder{conditions=%d}", conditions.size());
    }
}
