package pl.mikof.lootapi;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Główne API do modyfikacji loot tables
 * Każda operacja jest szczegółowo logowana za pomocą LootLogger
 */
public class LootTableAPI {
    public static final Logger LOGGER = LoggerFactory.getLogger("LootTableAPI");
    
    // Przechowuje wszystkie modyfikatory dla loot tables
    private static final Map<class_2960, LootTableModifier> modifiers = new ConcurrentHashMap<>();
    
    // Przechowuje mnożniki dropów
    private static final Map<class_2960, Float> multipliers = new ConcurrentHashMap<>();
    
    // Statystyki
    private static final List<String> loadedModifications = new ArrayList<>();
    private static int totalTablesModified = 0;
    private static int totalItemsAffected = 0;
    
    /**
     * Priorytety dla modyfikatorów
     */
    public enum Priority {
        LOWEST(0),
        LOW(25),
        NORMAL(50),
        HIGH(75),
        HIGHEST(100);
        
        private final int value;
        
        Priority(int value) {
            this.value = value;
        }
        
        public int getValue() {
            return value;
        }
    }
    
    /**
     * Dodaje item do istniejącego loot table
     * 
     * @param tableId Identifier loot table
     * @param item Item do dodania
     * @param weight Waga dropu
     */
    public static void addItemToTable(class_2960 tableId, class_1792 item, int weight) {
        if (!LootAPI.checkInitialized("add item to table")) return;
        
        try {
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(item).method_437(weight)));
            }, Priority.NORMAL);
            
            totalItemsAffected++;
            
            String modification = String.format("Added %s (weight: %d) to %s", 
                itemId, weight, tableId);
            loadedModifications.add(modification);
            
            // Loguj tylko w trybie debug
            if (LootLogger.isDebugEnabled()) {
                LootLogger.logItemAdded(tableId, item, weight);
            }
            
        } catch (Exception e) {
            LootLogger.logError("addItemToTable", tableId, e);
        }
    }
    
    /**
     * Dodaje item z określoną ilością
     */
    public static void addItemWithCount(class_2960 tableId, class_1792 item, int weight, int min, int max) {
        if (!LootAPI.checkInitialized("add item with count")) return;
        
        try {
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(item)
                        .method_437(weight)
                        .method_438(class_141.method_621(
                            class_5662.method_32462(min, max)))));
            }, Priority.NORMAL);
            
            totalItemsAffected++;
            
            // Loguj tylko w trybie debug
            if (LootLogger.isDebugEnabled()) {
                LootLogger.logModification("Added with count", tableId, item, 
                    "weight: " + weight, "count: " + min + "-" + max);
            }
            
        } catch (Exception e) {
            LootLogger.logError("addItemWithCount", tableId, e);
        }
    }
    
    /**
     * Usuwa item z loot table
     */
    public static void removeItemFromTable(class_2960 tableId, class_1792 itemToRemove) {
        if (!LootAPI.checkInitialized("remove item from table")) return;
        
        try {
            class_2960 itemId = class_7923.field_41178.method_10221(itemToRemove);
            
            registerModifier(tableId, builder -> {
                // Implementacja usuwania - wymaga mixinów lub zaawansowanej logiki
                LootLogger.logItemRemoved(tableId, itemToRemove);
            }, Priority.HIGH);
            
            totalItemsAffected++;
            String modification = String.format("Removed %s from %s", itemId, tableId);
            loadedModifications.add(modification);
            
        } catch (Exception e) {
            LootLogger.logError("removeItemFromTable", tableId, e);
        }
    }
    
    /**
     * Zastępuje item innym
     */
    public static void replaceItem(class_2960 tableId, class_1792 oldItem, class_1792 newItem) {
        if (!LootAPI.checkInitialized("replace item")) return;
        
        try {
            class_2960 oldItemId = class_7923.field_41178.method_10221(oldItem);
            class_2960 newItemId = class_7923.field_41178.method_10221(newItem);
            
            registerModifier(tableId, builder -> {
                // Implementacja zamiany
                LootLogger.logItemReplaced(tableId, oldItem, newItem);
            }, Priority.HIGH);
            
            totalItemsAffected += 2;
            String modification = String.format("Replaced %s with %s in %s", 
                oldItemId, newItemId, tableId);
            loadedModifications.add(modification);
            
        } catch (Exception e) {
            LootLogger.logError("replaceItem", tableId, e);
        }
    }
    
    /**
     * Ustawia mnożnik dropów dla loot table
     */
    public static void multiplyDrops(class_2960 tableId, float multiplier) {
        if (!LootAPI.checkInitialized("multiply drops")) return;
        
        multipliers.put(tableId, multiplier);
        LootLogger.logMultiplier(tableId, multiplier);
        
        registerModifier(tableId, builder -> {
            // Implementacja mnożnika
        }, Priority.LOW);
    }
    
    /**
     * Pobiera mnożnik dla loot table
     */
    public static Float getMultiplier(class_2960 tableId) {
        return multipliers.get(tableId);
    }
    
    /**
     * Tworzy nowy loot table
     */
    public static void createLootTable(class_2960 tableId, Consumer<class_52.class_53> builderConsumer) {
        if (!LootAPI.checkInitialized("create loot table")) return;
        
        try {
            registerModifier(tableId, builderConsumer, Priority.HIGHEST);
            LootLogger.logNewLootTable(tableId, "custom");
            totalTablesModified++;
            
        } catch (Exception e) {
            LootLogger.logError("createLootTable", tableId, e);
        }
    }
    
    /**
     * Rejestruje modyfikator z priorytetem
     */
    public static void registerModifier(class_2960 tableId, Consumer<class_52.class_53> modifier, Priority priority) {
        LootTableModifier tableModifier = modifiers.computeIfAbsent(tableId, k -> new LootTableModifier());
        tableModifier.addModifier(modifier, priority);
        totalTablesModified++;
    }
    
    /**
     * Rejestruje modyfikator z domyślnym priorytetem
     */
    public static void registerModifier(class_2960 tableId, Consumer<class_52.class_53> modifier) {
        registerModifier(tableId, modifier, Priority.NORMAL);
    }
    
    /**
     * Kopiuje loot table
     */
    public static void copyLootTable(class_2960 source, class_2960 target) {
        if (!LootAPI.checkInitialized("copy loot table")) return;
        
        if (modifiers.containsKey(source)) {
            LootTableModifier sourceModifier = modifiers.get(source);
            modifiers.put(target, sourceModifier.copy());
            LootLogger.logModification("Copied table", source, "to", target);
        }
    }
    
    /**
     * Eksportuje loot table do JSON
     */
    public static void exportToJson(class_2960 tableId, String filepath) {
        LOGGER.info("Exporting loot table {} to {}", tableId, filepath);
        // Implementacja eksportu do JSON
    }
    
    /**
     * Zwraca wszystkie zarejestrowane modyfikatory
     */
    public static Map<class_2960, LootTableModifier> getModifiers() {
        return Collections.unmodifiableMap(modifiers);
    }
    
    /**
     * Zwraca liczbę zmodyfikowanych tabel
     */
    public static int getTotalTablesModified() {
        return totalTablesModified;
    }
    
    /**
     * Zwraca liczbę zmienionych itemów
     */
    public static int getTotalItemsAffected() {
        return totalItemsAffected;
    }
    
    /**
     * Zwraca listę wszystkich załadowanych modyfikacji
     */
    public static List<String> getLoadedModifications() {
        return new ArrayList<>(loadedModifications);
    }
    
    /**
     * Resetuje liczniki
     */
    public static void resetCounters() {
        loadedModifications.clear();
        totalTablesModified = 0;
        totalItemsAffected = 0;
    }
    
    /**
     * Dodaje item z dokładną szansą (w procentach)
     * Użyj tej metody gdy chcesz DOKŁADNIE X% szansy na drop
     * 
     * @param tableId Identifier loot table
     * @param item Item do dodania
     * @param chancePercent Szansa w procentach (0-100, np. 35 = 35%)
     */
    public static void addItemWithChance(class_2960 tableId, class_1792 item, float chancePercent) {
        if (!LootAPI.checkInitialized("add item with chance")) return;
        
        try {
            float chance = chancePercent / 100.0f;  // Konwertuj procenty na 0-1
            
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(net.minecraft.class_219.method_932(chance))
                    .method_351(class_77.method_411(item).method_437(100)));
            }, Priority.NORMAL);
            
            totalItemsAffected++;
            
            // Loguj tylko w trybie debug
            if (LootLogger.isDebugEnabled()) {
                LootLogger.logModification("Added with chance", tableId, item, 
                    chancePercent + "% chance");
            }
            
        } catch (Exception e) {
            LootLogger.logError("addItemWithChance", tableId, e);
        }
    }
    
    /**
     * Dodaje item z dokładną szansą I określoną ilością
     * 
     * @param tableId Identifier loot table
     * @param item Item do dodania
     * @param chancePercent Szansa w procentach (0-100)
     * @param minCount Minimalna ilość
     * @param maxCount Maksymalna ilość
     */
    public static void addItemWithChance(class_2960 tableId, class_1792 item, float chancePercent,
                                        int minCount, int maxCount) {
        if (!LootAPI.checkInitialized("add item with chance and count")) return;
        
        try {
            float chance = chancePercent / 100.0f;
            
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(net.minecraft.class_219.method_932(chance))
                    .method_351(class_77.method_411(item)
                        .method_437(100)
                        .method_438(class_141.method_621(
                            class_5662.method_32462(minCount, maxCount)))));
            }, Priority.NORMAL);
            
            totalItemsAffected++;
            
            // Loguj tylko w trybie debug
            if (LootLogger.isDebugEnabled()) {
                LootLogger.logModification("Added with chance and count", tableId, item, 
                    chancePercent + "% chance", minCount + "-" + maxCount + " items");
            }
            
        } catch (Exception e) {
            LootLogger.logError("addItemWithChance", tableId, e);
        }
    }
    
    /**
     * Dodaje item z warunkiem Fortune
     */
    public static void addItemWithFortune(class_2960 tableId, class_1792 item, int baseWeight, 
                                         int fortuneMin, int fortuneMax) {
        if (!LootAPI.checkInitialized("add item with fortune")) return;
        
        try {
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(item)
                        .method_437(baseWeight)
                        .method_438(net.minecraft.class_94.method_455(
                            net.minecraft.class_1893.field_9130))));
            }, Priority.NORMAL);
            
            totalItemsAffected++;
            
            // Loguj tylko w trybie debug
            if (LootLogger.isDebugEnabled()) {
                LootLogger.logModification("Added with Fortune", tableId, item, 
                    "base weight: " + baseWeight, "fortune: " + fortuneMin + "-" + fortuneMax);
            }
            
        } catch (Exception e) {
            LootLogger.logError("addItemWithFortune", tableId, e);
        }
    }
    
    /**
     * Dodaje grupę itemów z wagami
     */
    public static void addWeightedGroup(class_2960 tableId, WeightedItemGroup group) {
        if (!LootAPI.checkInitialized("add weighted group")) return;
        
        try {
            registerModifier(tableId, builder -> {
                class_55.class_56 pool = class_55.method_347()
                    .method_352(class_44.method_32448(1));
                
                group.getItems().forEach((item, weight) -> {
                    pool.method_351(class_77.method_411(item).method_437(weight));
                });
                
                builder.method_336(pool);
            }, Priority.NORMAL);
            
            totalItemsAffected += group.getItems().size();
            
            // Loguj tylko w trybie debug
            if (LootLogger.isDebugEnabled()) {
                LootLogger.logModification("Added weighted group", tableId, 
                    "items: " + group.getItems().size());
            }
            
        } catch (Exception e) {
            LootLogger.logError("addWeightedGroup", tableId, e);
        }
    }
    
    /**
     * Dodaje item do wszystkich pasujących loot tables (wildcard)
     */
    public static void addToMatching(String pattern, class_1792 item, int weight) {
        if (!LootAPI.checkInitialized("add to matching")) return;
        
        int matchCount = 0;
        
        // Konwertuj pattern na regex
        String regex = pattern.replace("*", ".*");
        
        // Sprawdź wszystkie vanilla loot tables
        for (java.lang.reflect.Field field : LootTables.Blocks.class.getDeclaredFields()) {
            try {
                if (field.getType() == class_2960.class) {
                    class_2960 id = (class_2960) field.get(null);
                    if (id.toString().matches(regex)) {
                        addItemToTable(id, item, weight);
                        matchCount++;
                    }
                }
            } catch (Exception ignored) {}
        }
        
        LootLogger.logBulkOperation(pattern, matchCount);
    }
    
    /**
     * Debug - wyświetla zawartość loot table
     */
    public static void debugLootTable(class_2960 tableId) {
        LootLogger.logDebug(tableId);
        
        if (modifiers.containsKey(tableId)) {
            LootTableModifier modifier = modifiers.get(tableId);
            LootLogger.logDebugInfo("Modifiers", modifier.getModifierCount());
            LootLogger.logDebugInfo("Priority distribution", modifier.getPriorityDistribution());
        } else {
            LootLogger.logDebugInfo("Status", "No modifiers registered");
        }
    }
    
    /**
     * Wyświetla podsumowanie
     */
    public static void logSummary() {
        LootLogger.logSummary(totalTablesModified, LootLogger.getModificationCount());
    }
    
    // ========== ZAAWANSOWANE OPERACJE ==========
    
    /**
     * Wyłącza loot table (nic nie dropuje)
     * Użyj tego gdy chcesz całkowicie usunąć dropy z bloku/moba
     * 
     * @param tableId Identifier loot table
     */
    public static void disableLootTable(class_2960 tableId) {
        if (!LootAPI.checkInitialized("disable loot table")) return;
        
        try {
            registerModifier(tableId, builder -> {
                // Nie dodajemy żadnych poolów = nic nie dropuje
            }, Priority.HIGHEST);
            
            LootLogger.logWarning("Disabled loot table: " + tableId + " (no drops)");
            
        } catch (Exception e) {
            LootLogger.logError("disableLootTable", tableId, e);
        }
    }
    
    /**
     * Sprawia że blok/mob dropuje TYLKO określony item (czyści resztę)
     * 
     * @param tableId Identifier loot table
     * @param item Item który ma być jedynym dropem
     * @param weight Waga
     */
    public static void setOnlyDrop(class_2960 tableId, class_1792 item, int weight) {
        if (!LootAPI.checkInitialized("set only drop")) return;
        
        try {
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(item).method_437(weight)));
            }, Priority.HIGHEST);
            
            LootLogger.logInfo("Set " + tableId + " to drop only: " + itemId);
            
        } catch (Exception e) {
            LootLogger.logError("setOnlyDrop", tableId, e);
        }
    }
    
    /**
     * Sprawia że blok/mob dropuje TYLKO określony item z ilością
     * 
     * @param tableId Identifier loot table
     * @param item Item który ma być jedynym dropem
     * @param minCount Min ilość
     * @param maxCount Max ilość
     */
    public static void setOnlyDrop(class_2960 tableId, class_1792 item, int minCount, int maxCount) {
        if (!LootAPI.checkInitialized("set only drop with count")) return;
        
        try {
            class_2960 itemId = class_7923.field_41178.method_10221(item);
            
            registerModifier(tableId, builder -> {
                builder.method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(item)
                        .method_437(100)
                        .method_438(class_141.method_621(
                            class_5662.method_32462(minCount, maxCount)))));
            }, Priority.HIGHEST);
            
            LootLogger.logInfo("Set " + tableId + " to drop only: " + itemId + " (" + minCount + "-" + maxCount + ")");
            
        } catch (Exception e) {
            LootLogger.logError("setOnlyDrop", tableId, e);
        }
    }
}
